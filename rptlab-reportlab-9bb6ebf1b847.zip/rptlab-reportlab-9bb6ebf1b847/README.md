# Old ReportLab Toolkit Source

This is a dead version of reportlab because Bitbucket will cease supporting mercurial.

## Please download from

[https://hg.reportlab.com/hg-public/reportlab](https://hg.reportlab.com/hg-public/reportlab)

and use the users mailing list by subscribing to the mailman list at

[https://pairlist2.pair.net/mailman/listinfo/reportlab-users](https://pairlist2.pair.net/mailman/listinfo/reportlab-users)

for those who prefer git we maintain a mirror at

[https://github.com/MrBitBucket/reportlab-mirror](https://github.com/MrBitBucket/reportlab-mirror)

Any pull requests / issues etc etc will be ignored unless a good case is made in the users  
mailing list.
